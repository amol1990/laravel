@extends('master');

@section('title','| Contact us')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <h3>Contact Me</h3>
            <hr>
            <form>
                <div class="form-group">
                    <label >Email:</label>
                    <input name="email" class="form-control">
                </div>
                <div class="form-group">
                    <label >Subject:</label>
                    <input name="subject"  id= "subject"  class="form-control">
                </div>
                <div class="formgroup">
                <label>Message:</label>
                <textarea class="form-control" name="message" id="message" cols="30" rows="10" class="message">please enter your message..</textarea>
                </div>
                <input class="btn btn-success" type="submit" value="Send Message">
            </form>
        </div>
    </div>
 @endsection   
    
