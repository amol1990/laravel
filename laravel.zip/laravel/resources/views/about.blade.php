@extends('master');

@section('title','| About us')

@section('content');

    <div class="row">
        <div class="col-md-12">
            <h3>About Me</h3>
            <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Similique accusantium nam atque possimus placeat fuga? Repellat consectetur ratione inventore beatae enim facilis minima labore soluta necessitatibus, culpa magni sint maxime!</P>
        </div>
    </div>
@endsection;