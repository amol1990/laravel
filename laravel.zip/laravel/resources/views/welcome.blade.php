@extends('master');
 
 @section('content');
    <div class="row">
        <div class="col-md-12">
            <div class="jumbotron">
                <h1>Welcome to laravel blog</h1>
                <p>Please read some poular post </p>
                <p><a class="btn btn-primary btn-lg" href="#" role="button">Poular Post </a></p>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-8">
        <div class="post">
          <h3>Title </h3>
            <p class='alert-success'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa natus voluptate sequi numquam error eaque voluptatum dignissimos, fugit aut illo sint ullam vel, in hic qui aspernatur assumenda voluptatibus dolorem!</p>
            <a href="" class="btn btn-primary">Read more</a>
        </div>
        <hr>
        <div class="post">
          <h3>Title </h3>
            <p class='alert-success'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa natus voluptate sequi numquam error eaque voluptatum dignissimos, fugit aut illo sint ullam vel, in hic qui aspernatur assumenda voluptatibus dolorem!</p>
            <a href="" class="btn btn-primary">Read more</a>
        </div>
        <hr>
        <div class="post">
          <h3>Title </h3>
            <p class='alert-success'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa natus voluptate sequi numquam error eaque voluptatum dignissimos, fugit aut illo sint ullam vel, in hic qui aspernatur assumenda voluptatibus dolorem!</p>
            <a href="" class="btn btn-primary">Read more</a>
        </div>
        <hr>
        <div class="post">
          <h3>Title </h3>
            <p class='alert-success'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa natus voluptate sequi numquam error eaque voluptatum dignissimos, fugit aut illo sint ullam vel, in hic qui aspernatur assumenda voluptatibus dolorem!</p>
            <a href="" class="btn btn-primary">Read more</a>
        </div>
        </div>
        <div class="col-md-3 col-md-offset-1"><p class="alert-danger"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa natus voluptate sequi numquam error eaque voluptatum dignissimos, fugit aut illo sint ullam vel, in hic qui aspernatur assumenda voluptatibus dolorem!</p></div>
    </div>
@endsection;