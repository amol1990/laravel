<?php $__env->startSection('title','| create post'); ?>

<?php $__env->startPush('style'); ?>

	{<?php echo Html::style('css/parsley.css'); ?>}
<?php $__env->stopPush(); ?> 
<?php $__env->startSection('content'); ?>
	<div class="row">
	 	<div class="col-md-8 col-md-offset-2">
			<?php echo e(Form::open(array('route'=>'posts.store','data-parsley-validate'=>'','id'=>'form') )); ?>

			<?php echo e(Form::label('title','Title:')); ?>

			<?php echo e(Form::text('title',null,array('class'=>'form-control','required'=>'','maxlength'=>'250'))); ?>


			<?php echo e(Form::label('body','Body:')); ?>

			<?php echo e(Form::textarea('body',null,array('class'=>'form-control','required'=>''))); ?>

						
			<?php echo e(Form::submit('Create Post',array('class'=>'btn btn-success btn-lg btn-block'))); ?>

		
			<?php echo e(Form::close()); ?> 					
	 	</div>
	</div> 			
	
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

	{<?php echo Html::script('js/validate.js'); ?>}
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>