;

<?php $__env->startSection('title','| About us'); ?>

<?php $__env->startSection('content'); ?>;

    <div class="row">
        <div class="col-md-12">
            <h3>About Me</h3>
            <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Similique accusantium nam atque possimus placeat fuga? Repellat consectetur ratione inventore beatae enim facilis minima labore soluta necessitatibus, culpa magni sint maxime!</P>
        </div>
    </div>
<?php $__env->stopSection(); ?>;
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>