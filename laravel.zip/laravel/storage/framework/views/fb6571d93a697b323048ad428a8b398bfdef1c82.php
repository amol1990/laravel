<?php $__env->startSection('title','|All Post'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-10">
		<h1>All Posts </h1>
	</div>
	<div class="col-md-2">
	
		<?php echo e(Html::linkRoute('posts.create','Create Post',array(''),array('class'=>'btn btn-primary'))); ?>

	</div>

	<div class="col-md-12">
		<hr>
	</div>
</div>

<div class="row">
<div class="col-md-12">

	<table class="table">
	<thead> 
		<th>No</th>
		<th>Title</th>
		<th>Body</th>
		<th>Created At</th>
		<th></th>

	</thead>
	<tbody>
		<?php foreach($posts as $post): ?>		
			<tr>
				<td><?php echo e($post->id); ?></td>
				<td><?php echo e($post->title); ?></td>
				<td><?php echo e(substr( $post->body,0,60)); ?><?php echo e(strlen($post->body) >50 ?"...":""); ?> </td>
				<td><?php echo e(date( 'M j, Y H:i a',strtotime($post->created_at))); ?></td>
				<td>
				<?php echo Html::linkRoute('posts.show','view',array($post->id),array('class'=>'btn btn-primary btn-sm')); ?>

				<?php echo Html::linkRoute('posts.edit','Edit',array($post->id),array('class'=>'btn btn-primary btn-sm')); ?></td>
			</tr>
	<?php endforeach; ?>

	</tbody>
	</table>
	<div class="text-center">
		<?php echo $posts->links(); ?>}
	</div>
</div>
</div>

<?php $__env->stopSection(); ?>;
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>