<?php

namespace App\Http\Controllers;

class Pages extends Controller
 {
 	Public function getAbout(){

 		$name='amol';
 		$last='rakshe';

 		$fullname =$name." ". $last ;
 		$data[]="";
 		$data['email']="amol@amol.com";
 		$data['address']="navi mumbai";
 		$data['full']=$fullname; 

 		return view('about')->with('data',$data);
 	}

 	public function getcontact(){

 		return view('contact');
 	}


 }



?>
